// ************ post-name Start ***********************  //
// onload get data
jQuery( document ).ready(function() {set_action_ca();});

// change cat get data 
jQuery( "#years, #make" ).live('change',function() {set_action_ca();});

// submit text get data
jQuery( "#ca_submit" ).live("click",function() {set_action_ca();});

// load more get data
jQuery( ".load_more" ).live("click",function() {
	jQuery('#ca_paged').val(jQuery('.load_more').attr('paged'));
	jQuery( ".load_more" ).remove( ".load_more" );
	get_content_ca();
});

// ajax data set 
function get_content_ca()
{	jQuery('#load_image img').show();
	jQuery.ajax({
		url : ca_ajax_object.ajax_url,
		type : 'post',
		data : jQuery("#consumer_alerts").serialize(),
		success : function( response ) {
			jQuery('#consumer_alerts_list').append( response );
			jQuery('#load_image img').hide();
		}
	});
}

// Call action function 
function set_action_ca()
{
	jQuery('#ca_paged').val(1);
	jQuery('#consumer_alerts_list').html('');
	get_content_ca();
}
// ************ post-name End ***********************  //