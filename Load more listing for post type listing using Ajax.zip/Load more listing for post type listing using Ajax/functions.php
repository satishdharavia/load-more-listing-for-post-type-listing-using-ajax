<?php

// ************ post-name Start ***********************  //
// script add ajax
function ca_enqueue() {
    wp_enqueue_script( 'ajax-script', get_stylesheet_directory_uri() . '/js/custom.js', array('jquery') );
    wp_localize_script( 'ajax-script', 'ca_ajax_object',array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
}
add_action( 'wp_enqueue_scripts', 'ca_enqueue' );

// add ajax function ca list
add_action( 'wp_ajax_nopriv_ca_list', 'ca_list' );
add_action( 'wp_ajax_ca_list', 'ca_list' );
function ca_list() {
	
	$paged = $_POST['paged'];
	$args = array(
	'posts_per_page'=> 2,
	'paged'         => $paged,
	'post_type'     => 'post-name',
	'post_status'   => 'publish',
	's'				=> $_POST['defects'],
	);
	if((isset($_POST['years']) && ($_POST['years'] != '-1')) && (isset($_POST['make']) && ($_POST['make'] != '-1')))
	{$args['tax_query'][] = array('relation' => 'AND');}
	if(isset($_POST['years']) && ($_POST['years'] != '-1'))
	{$args['tax_query'][] = array(
						'taxonomy' => 'years',
						'field' => 'slug',
						'terms' => array ($_POST['years'])
					);
	}
	if(isset($_POST['make']) && ($_POST['make'] != '-1'))
	{
	$args['tax_query'][] = array(
						'taxonomy' => 'make',
						'field' => 'slug',
						'terms' => array ($_POST['make'])
					);
	}
	/*if(isset($_POST['defects']) && ($_POST['defects'] != ''))
	{
	$args['meta_query'][] = array(
								'key'     => 'defects',
								'value'   => $_POST['defects'],
								'compare' => 'LIKE',
							);
	}*/	
	
	$data = new wp_query( $args );
	
	if($data->post_count == 0)
	{
		?>
		<div>Data not found</div>
		<?php
	}
	foreach($data->posts as $val)
	{
		echo '<div><div><a href="'.get_permalink($val->ID).'">'.$val->post_title.'</a></div>';
		echo '<img src="'.get_the_post_thumbnail_url($val->ID,$size = 'thumbnail').'">';
		echo '<div>'.get_the_date(get_option('date_format'),$val->ID).'</div>';
		echo '<div>'.the_field('defects',$val->ID).'</div>';
		echo '<a href="'.get_permalink($val->ID).'"> Read more ->  </a></div>';
	}
	if($data->max_num_pages > $data->query['paged']){
	?>
	<div class="load_more" paged='<?php echo $data->query['paged']+1;?>' style="cursor: pointer;">Load more</div>
	<?php 
	}
	die();
}

// save content data
add_action('save_post','save_post_ca');
function save_post_ca($post_id){
    global $post; 
    if ($post->post_type != 'post-name'){
        return;
    }
	
	if(isset($_POST['acf']['field_5c123de814948']) && ($_POST['acf']['field_5c123de814948'] != ''))
	{
		global $wpdb;
		
		$wpdb->query($wpdb->prepare('UPDATE '.$wpdb->prefix.'posts SET post_content = "'.$_POST['acf']['field_5c123de814948'].'" WHERE ID = '.$post_id.';'));
	}
    //if you get here then it's your post type so do your thing....
}
// ************ post-name End ***********************  //

