<?php get_header(); ?>

<div id="main-content">
	<div class="container">
		<div id="content-area" class="clearfix">
			<div id="left-area">
			<form name="consumer_alerts" id="consumer_alerts" onSubmit="return false">
				<?php 
				  $categories = get_categories('taxonomy=years');
 
				  $select = "<select name='years' id='years' class='postform'>";
				  $select.= "<option value='-1'>Select years</option>";
				 
				  foreach($categories as $category){
					if($category->count > 0){
						$select.= "<option value='".$category->slug."'>".$category->name."</option>";
					}
				  }
				 
				  $select.= "</select>";
				 
				  echo $select;
				?>
				<?php 
				  $categories = get_categories('taxonomy=make');
 
				  $select = "<select name='make' id='make' class='postform'>";
				  $select.= "<option value='-1'>Select make</option>";
				 
				  foreach($categories as $category){
					if($category->count > 0){
						$select.= "<option value='".$category->slug."'>".$category->name."</option>";
					}
				  }
				 
				  $select.= "</select>";
				 
				  echo $select;
				?>
				<input type="text" name="defects" value="">
				<input type="hidden" name="action" value="ca_list">
				<input type="hidden" id="ca_paged" name="paged" value="1">
				<input type="button" id="ca_submit" value="Submit">
			</form>
			<div id="consumer_alerts_list">
			</div>
			<div id="load_image"><img src="<?php echo get_stylesheet_directory_uri() . '/images/load-image.gif'?>" width="50px" style="display:none"></div>
			</div> <!-- #left-area -->

			<?php get_sidebar(); ?>
		</div> <!-- #content-area -->
	</div> <!-- .container -->
</div> <!-- #main-content -->
<?php

get_footer();
